#include "cachelab.h"
#include <stdio.h>
#include <getopt.h>
#include <stdlib.h>
#include <unistd.h>
/******************
 *Authors
 *
 *Asher Gingerich
 *John Khol
 ******************/
int s;
int E;
int b;
char *trace;

void checkFlags(int count, char *value[]) {
    int c;
    while((c = getopt(count, value, "hvs:E:b:t:")) != -1) {
        switch(c) {
            case 'h':
                printf("Case h called!\n");
                break;
            case 'v':
                printf("Case v called!\n");
                break;
            case 's':
                printf("Case s called!\n");
                s = atoi(optarg);
                break;
            case 'E':
                printf("Case E called!\n");
                E = atoi(optarg);
                break;
            case 'b':
                printf("Case b called!\n");
                b = atoi(optarg);
                break;
            case 't':
                printf("Case t called!\n");
                trace = optarg;
                break;
        }
    }
}

void simulate(long *cache) {
    FILE *file;
    file = fopen(trace,"r");
    char buff[255];
    char operation;
    char place;
    char num[255];
    unsigned long blockOff;
    unsigned long setIn;
    unsigned long tag;
    unsigned long address;
    //Read file line by line
    while((place = fgetc(file)) != EOF){
        if(place != ' ') {
            printf("Instruction line \n");
            fgets(buff, 255, file);
        }else{
            operation = fgetc(file);
            fgetc(file);
            printf("Cache Line! %c\n", operation);
            fgets(buff, 255, file);
            printf("%s", buff);
            //Grab address
            for(int i = 0; i < 255; i++) {
                if(buff[i] == ',') {
                    num[i] = 0;
                    break;
                }
                num[i] = buff[i];
            }
            //Grab relevant bits for cache
            address = strtol(num, NULL, 16);
            blockOff = address & (~(-1 << b));
            setIn = (address >> b) & (~(-1 << s));
            tag = address >> (s+b);
            
            //TODO: check hit or miss on cache
            for(int k = 0; k < E; k++) {
               address = cache[setIn * E] + k;
            }
            //switch(operation) {
            //}
        }
    }

    fclose(file);

}

int main(int argc, char *argv[])
{
    //Read command line arguments
    checkFlags(argc, argv);
    //Setup cache simulation
    int numSet = 1 << s;
    long *cache = (long *) calloc(numSet * E, 8);
    //Simulate the cache
    simulate(cache);

    //Print out counts
    //hit_count, miss_count, eviction_count
    printSummary(0, 0, 0);
    free(cache);
    return 0;
}


